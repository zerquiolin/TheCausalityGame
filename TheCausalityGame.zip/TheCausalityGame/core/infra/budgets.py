from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Final


@dataclass(frozen=True, slots=True)
class _MonotonicClock:
    """Thin wrapper over time.perf_counter() for testability."""

    start: float

    @classmethod
    def start_now(cls) -> "_MonotonicClock":
        return cls(start=time.perf_counter())

    def elapsed(self) -> float:
        """Return elapsed seconds since start using a monotonic clock."""
        return time.perf_counter() - self.start


class RoundBudget:
    """Round-based budget controller.

    This budget counts how many times `step()` is called and raises when the
    configured limit is exceeded.

    Attributes:
        max_rounds: Maximum number of rounds allowed (>= 1).
    """

    __slots__ = ("_max_rounds", "_used")

    def __init__(self, max_rounds: int) -> None:
        if max_rounds < 1:
            raise ValueError("max_rounds must be >= 1")
        self._max_rounds: Final[int] = max_rounds
        self._used: int = 0

    def step(self) -> None:
        """Consume one round; raise if the budget is exceeded."""
        self._used += 1
        if self._used > self._max_rounds:
            raise RuntimeError("Round budget exceeded")

    @property
    def used(self) -> int:
        """Number of rounds consumed so far."""
        return self._used

    @property
    def remaining(self) -> int:
        """Number of rounds remaining (never negative)."""
        rem = self._max_rounds - self._used
        return rem if rem >= 0 else 0

    @property
    def max_rounds(self) -> int:
        """Configured maximum number of rounds."""
        return self._max_rounds

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"RoundBudget(max_rounds={self._max_rounds}, used={self._used})"


class SamplesBudget:
    """Sample-count budget controller.

    Tracks the cumulative number of samples requested by an agent and raises
    once the allowed quota is exceeded.

    Attributes:
        max_samples: Maximum number of samples allowed (>= 0).
    """

    __slots__ = ("_max_samples", "_used")

    def __init__(self, max_samples: int) -> None:
        if max_samples < 0:
            raise ValueError("max_samples must be >= 0")
        self._max_samples: Final[int] = max_samples
        self._used: int = 0

    def consume(self, n: int) -> None:
        """Consume `n` samples; raise if the budget is exceeded.

        Args:
            n: Number of samples to add (>= 0).
        """
        if n < 0:
            raise ValueError("n must be >= 0")
        self._used += n
        if self._used > self._max_samples:
            raise RuntimeError("Samples budget exceeded")

    @property
    def used(self) -> int:
        """Total samples consumed so far."""
        return self._used

    @property
    def remaining(self) -> int:
        """Remaining sample quota (never negative)."""
        rem = self._max_samples - self._used
        return rem if rem >= 0 else 0

    @property
    def max_samples(self) -> int:
        """Configured maximum number of samples."""
        return self._max_samples

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"SamplesBudget(max_samples={self._max_samples}, used={self._used})"


class TimeBudget:
    """Wall-clock time budget controller based on a monotonic clock.

    Attributes:
        max_seconds: Maximum allowed elapsed time in seconds (>= 0).
    """

    __slots__ = ("_max_seconds", "_clock")

    def __init__(self, max_seconds: float) -> None:
        if max_seconds < 0:
            raise ValueError("max_seconds must be >= 0")
        self._max_seconds: Final[float] = float(max_seconds)
        self._clock: _MonotonicClock = _MonotonicClock.start_now()

    def check(self) -> None:
        """Raise if the elapsed time exceeds the configured budget."""
        if self.elapsed >= self._max_seconds:
            raise RuntimeError("Time budget exceeded")

    @property
    def elapsed(self) -> float:
        """Elapsed seconds since the budget started."""
        return self._clock.elapsed()

    @property
    def remaining(self) -> float:
        """Remaining time in seconds (never negative)."""
        rem = self._max_seconds - self.elapsed
        return rem if rem >= 0 else 0.0

    @property
    def max_seconds(self) -> float:
        """Configured maximum number of seconds."""
        return self._max_seconds

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"TimeBudget(max_seconds={self._max_seconds:.6f}, elapsed={self.elapsed:.6f})"
