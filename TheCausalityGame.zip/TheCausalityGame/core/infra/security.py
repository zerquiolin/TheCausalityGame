"""Security policy flags and helpers."""

from __future__ import annotations


RESTRICTED_MODE_DEFAULT = True


def network_allowed() -> bool:
    """Return False to disallow network access by default (enforced later)."""
    return False
