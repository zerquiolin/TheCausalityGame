# from __future__ import annotations

# import json
# import math
# from dataclasses import asdict, is_dataclass
# from enum import Enum
# from pathlib import Path
# from typing import Any, Final

# try:  # Optional dependency handling (no hard import)
#     import numpy as _np  # type: ignore
# except Exception:  # pragma: no cover
#     _np = None  # type: ignore[assignment]


# class _JSONEncoder(json.JSONEncoder):
#     """Strict JSON encoder with safe fallbacks for common Python/numpy types."""

#     def default(self, o: Any) -> Any:  # noqa: D401
#         """Return a JSON-serializable representation of `o` or raise TypeError."""
#         # Dataclasses
#         if is_dataclass(o):
#             return asdict(o)

#         # Pathlib
#         if isinstance(o, Path):
#             return str(o)

#         # Enum → value
#         if isinstance(o, Enum):
#             return o.value

#         # Sets/tuples → lists
#         if isinstance(o, (set, tuple)):
#             return list(o)

#         # Pydantic BaseModel (avoid strict dependency)
#         if hasattr(o, "model_dump") and callable(getattr(o, "model_dump")):
#             return o.model_dump()  # type: ignore[no-any-return]

#         # Numpy scalars/arrays (if numpy is available)
#         if _np is not None:
#             if isinstance(o, (_np.int_, _np.integer)):  # type: ignore[attr-defined]
#                 return int(o)
#             if isinstance(o, (_np.floating,)):  # type: ignore[attr-defined]
#                 val = float(o)
#                 if math.isnan(val) or math.isinf(val):
#                     raise TypeError("NaN/Inf are not JSON-serializable")
#                 return val
#             if isinstance(o, (_np.ndarray,)):  # type: ignore[attr-defined]
#                 return o.tolist()

#         return super().default(o)


# def dumps(obj: Any, *, ensure_ascii: bool = False, indent: int | None = 2) -> str:
#     """Serialize an object to a JSON string using a strict, safe encoder.

#     Args:
#         obj: Object to serialize (must be JSON-compatible after transformation).
#         ensure_ascii: If True, escape non-ASCII characters. Default False.
#         indent: Indentation spaces for pretty output (None for compact).

#     Returns:
#         JSON string.

#     Raises:
#         TypeError: If an unsupported type is encountered (e.g., NaN/Inf).
#         ValueError: If circular references or invalid states are found by json.
#     """
#     return json.dumps(
#         obj, cls=_JSONEncoder, ensure_ascii=ensure_ascii, indent=indent, sort_keys=False
#     )


# def loads(data: str) -> Any:
#     """Parse a JSON string into a Python object.

#     Args:
#         data: JSON-encoded string.

#     Returns:
#         Python object (dict/list/str/number/None).

#     Raises:
#         json.JSONDecodeError: On invalid JSON input.
#     """
#     return json.loads(data)


# def get_class_path(obj_or_class: Any) -> str:
#     """Return 'module.path:ClassName' for a class or instance.

#     If a string with ':' is provided, it is returned unchanged (assumed already
#     in 'module:Class' form). If a string without ':' is provided, a ValueError
#     is raised to avoid ambiguity.

#     Args:
#         obj_or_class: A class, an instance, or a string in 'module:Class' form.

#     Returns:
#         Canonical class path string.

#     Raises:
#         ValueError: If a plain string (without ':') is provided.
#         TypeError: If the input cannot be mapped to a class path.
#     """
#     if isinstance(obj_or_class, str):
#         if ":" in obj_or_class:
#             return obj_or_class
#         raise ValueError("String must be in 'module:Class' form, e.g. 'pkg.mod:Type'.")

#     cls = obj_or_class if isinstance(obj_or_class, type) else type(obj_or_class)
#     module = getattr(cls, "__module__", None)
#     name = getattr(cls, "__name__", None)
#     if not module or not name:
#         raise TypeError(
#             f"Cannot derive class path from object of type {type(obj_or_class)!r}"
#         )
#     return f"{module}:{name}"

from __future__ import annotations

import json
import math
from dataclasses import asdict, is_dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Final

try:  # Optional dependency handling (no hard import)
    import numpy as _np  # type: ignore
except Exception:  # pragma: no cover
    _np = None  # type: ignore[assignment]


class _JSONEncoder(json.JSONEncoder):
    """Strict JSON encoder with safe fallbacks for common Python/numpy types."""

    def default(self, o: Any) -> Any:  # noqa: D401
        """Return a JSON-serializable representation of `o` or raise TypeError."""
        # Dataclasses
        if is_dataclass(o):
            return asdict(o)

        # Pathlib
        if isinstance(o, Path):
            return str(o)

        # Enum → value
        if isinstance(o, Enum):
            return o.value

        # Sets/tuples → lists
        if isinstance(o, (set, tuple)):
            return list(o)

        # Pydantic BaseModel (avoid strict dependency)
        if hasattr(o, "model_dump") and callable(getattr(o, "model_dump")):
            return o.model_dump()  # type: ignore[no-any-return]

        # Numpy scalars/arrays (if numpy is available)
        if _np is not None:
            if isinstance(o, (_np.int_, _np.integer)):  # type: ignore[attr-defined]
                return int(o)
            if isinstance(o, (_np.floating,)):  # type: ignore[attr-defined]
                val = float(o)
                if math.isnan(val) or math.isinf(val):
                    raise TypeError("NaN/Inf are not JSON-serializable")
                return val
            if isinstance(o, (_np.ndarray,)):  # type: ignore[attr-defined]
                return o.tolist()

        return super().default(o)


def dumps(obj: Any, *, ensure_ascii: bool = False, indent: int | None = 2) -> str:
    """Serialize an object to a JSON string using a strict, safe encoder.

    Enforces RFC 7159 compatibility by rejecting NaN/Infinity via allow_nan=False.

    Args:
        obj: Object to serialize (must be JSON-compatible after transformation).
        ensure_ascii: If True, escape non-ASCII characters. Default False.
        indent: Indentation spaces for pretty output (None for compact).

    Returns:
        JSON string.

    Raises:
        TypeError: If an unsupported type is encountered (e.g., NaN/Inf).
        ValueError: If circular references or invalid states are found by json.
    """
    return json.dumps(
        obj,
        cls=_JSONEncoder,
        ensure_ascii=ensure_ascii,
        indent=indent,
        sort_keys=False,
        allow_nan=False,  # <— strict JSON; makes test_dumps_rejects_nan_inf pass
    )


def loads(data: str) -> Any:
    """Parse a JSON string into a Python object.

    Args:
        data: JSON-encoded string.

    Returns:
        Python object (dict/list/str/number/None).

    Raises:
        json.JSONDecodeError: On invalid JSON input.
    """
    return json.loads(data)


def get_class_path(obj_or_class: Any) -> str:
    """Return 'module.path:ClassName' for a class or instance.

    - If a string with ':' is provided, it is returned unchanged.
    - If a plain string is provided (without ':'), a ValueError is raised.
    - For some stdlib classes (e.g., pathlib.Path), normalize private submodules
      (e.g., 'pathlib._local') to their public module ('pathlib').

    Args:
        obj_or_class: A class, an instance, or a string in 'module:Class' form.

    Returns:
        Canonical class path string.

    Raises:
        ValueError: If a plain string (without ':') is provided.
        TypeError: If the input cannot be mapped to a class path.
    """
    if isinstance(obj_or_class, str):
        if ":" in obj_or_class:
            return obj_or_class
        raise ValueError("String must be in 'module:Class' form, e.g. 'pkg.mod:Type'.")

    cls = obj_or_class if isinstance(obj_or_class, type) else type(obj_or_class)
    module = getattr(cls, "__module__", None)
    name = getattr(cls, "__name__", None)
    if not module or not name:
        raise TypeError(
            f"Cannot derive class path from object of type {type(obj_or_class)!r}"
        )

    # Normalize certain stdlib private module paths (observed in CI/PyPy/platforms)
    if module.startswith("pathlib._"):
        module = "pathlib"

    return f"{module}:{name}"
