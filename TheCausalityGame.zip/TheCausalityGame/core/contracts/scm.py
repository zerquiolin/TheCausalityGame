from __future__ import annotations

from typing import Any, Mapping

from .serializable import ConfigDictSerializable


class BaseSCM(ConfigDictSerializable):
    """SCM contract + serializable base."""

    def generate_samples(
        self,
        *,
        n: int | None,
        interventions: Mapping[str, Any] | None,
        seed: int | None,
    ) -> Mapping[str, list[Any]]:
        """Produce a dataset given do()-style interventions and a seed."""
        raise NotImplementedError
