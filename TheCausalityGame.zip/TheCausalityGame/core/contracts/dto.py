"""Data Transfer Objects (DTOs) for manifests and runtime records.

This module defines the *public contract* between user-provided components
(agents, missions, metrics, SCMs) and the core engine. All models are
validated with Pydantic, forbid extra fields, and are immutable where it
makes sense for configuration objects.

Conventions:
- JSON manifests use `"class": "module.path:ClassName"`; in Python we expose
  that field as `class_` with `alias="class"` to avoid the reserved keyword.
- Only JSON-serializable data is persisted in artifacts. Runtime-only objects
  (e.g., callables) should be handled by missions/metrics in trusted mode and
  not embedded in these DTOs.
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Mapping, Optional

from pydantic import BaseModel, ConfigDict, Field

# ---------- Common type alias ----------

JsonDict = dict[str, Any]


# ---------- Run plan & budgets ----------

# TODO: Use Pydantic V2 and fix the attributes of the models.


class BudgetSpec(BaseModel):
    """Resource budgets applied per agent run.

    Attributes:
        time_s: Optional wall-clock time budget in seconds.
        samples: Optional maximum number of samples the agent may request.
        memory_mb: Optional advisory memory budget in megabytes.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    time_s: float | None = Field(default=None, ge=0)
    samples: int | None = Field(default=None, ge=0)
    memory_mb: int | None = Field(default=None, ge=0)


class RunPlan(BaseModel):
    """Execution policy for agent runs.

    Runs are performed in isolated environments per agent. Execution can be
    sequential (one agent after the other) or parallel (concurrently).

    Attributes:
        rounds: Number of rounds per agent.
        execution: 'sequential' or 'parallel'.
        parallel_backend: 'thread' for I/O-bound or 'process' for CPU-bound runs.
        max_workers: Optional cap on parallel workers; None → auto.
        budgets: Resource budgets enforced per agent run.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    rounds: int = Field(ge=1)
    execution: Literal["sequential", "parallel"] = "sequential"
    parallel_backend: Literal["thread", "process"] = "thread"
    max_workers: int | None = Field(default=None, ge=1)
    budgets: BudgetSpec = Field(default_factory=BudgetSpec)


# ---------- Specs for pluggable components ----------


class AgentSpec(BaseModel):
    """Specification for constructing an agent.

    Attributes:
        id: Unique agent identifier for the run.
        class_: Import path 'module:Class' (aliased from 'class' in JSON).
        config: Optional agent configuration payload.
        priority: Optional priority hint (lower → earlier in sequential UIs).
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str
    class_: str = Field(alias="class")
    config: JsonDict = {}
    priority: int | None = Field(default=None, ge=0)


class MetricSpec(BaseModel):
    """Specification for constructing a metric."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str
    class_: str = Field(alias="class")
    config: JsonDict = {}


class MetricSpecs(BaseModel):
    """Canonical metric pair for each mission."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    behavior: MetricSpec
    result: MetricSpec


class HookSpec(BaseModel):
    """Specification for a runtime hook subscription.

    Attributes:
        id: Logical identifier for the hook subscription.
        class_path: Import path for a hook object implementing __call__(event,payload).
        entry_point: Alternative import path (kept for compatibility).
        events: Optional whitelist of event names this hook wants.
        priority: Ordering among hooks (lower runs earlier).
        requires: Other hook IDs that must run before this one.
        on_error: Policy when a hook raises ('ignore'|'warn'|'fail').
        config: Hook-specific configuration.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str
    class_path: str | None = None
    entry_point: str | None = None
    events: list[str] | None = None
    priority: int = 100
    requires: list[str] = []
    on_error: Literal["ignore", "warn", "fail"] = "warn"
    config: JsonDict = {}


# ---------- Problem instance (top-level manifest) ----------


class ProblemInstance(BaseModel):
    """Top-level manifest describing a benchmark run.

    Attributes:
        schema_version: Manifest schema version string.
        id: Run identifier (used as folder name under runs/).
        scm_spec: SCM specification {'class','config'}.
        mission_spec: Mission specification {'class','config'}.
        agent_specs: List of AgentSpec-like dicts (validated here).
        metric_specs: Pair of primary metrics (behavior & result).
        custom_metric_specs: Optional list of additional metrics.
        run_plan: Execution policy for the run.
        seeds: Seed hierarchy for determinism (global/scm/mission/agents).
        hook_plan: Hook subscriptions for lifecycle events.
        artifacts_policy: Global artifact toggles/policies.
    """

    model_config = ConfigDict(extra="forbid")

    schema_version: str = "1.0.0"
    id: str

    scm_spec: JsonDict
    mission_spec: JsonDict
    agent_specs: list[AgentSpec]

    metric_specs: MetricSpecs
    custom_metric_specs: list[MetricSpec] = []

    run_plan: RunPlan

    seeds: JsonDict = {}
    hook_plan: list[HookSpec] = []
    artifacts_policy: JsonDict = {}


# ---------- Runtime records written to transcripts & scoring ----------

# TODO: Observation & Action could be merged into a single model. (i.e., Step)


# TODO: Not useful at the moment. (Might be, check environment._apply_decision.)
class Observation(BaseModel):
    """Observation communicated to an agent (dataset, feedback, status)."""

    model_config = ConfigDict(extra="forbid")

    kind: Literal["dataset", "feedback", "status"]
    payload: JsonDict


# TODO: Not useful at the moment.
class Action(BaseModel):
    """Action normalized from an agent decision (JSON-safe)."""

    model_config = ConfigDict(extra="forbid")

    kind: Literal["intervene", "submit_partial", "submit_final"]
    payload: JsonDict


class StepRecord(BaseModel):
    """One micro-step record in the run transcript."""

    model_config = ConfigDict(extra="forbid")

    round_index: int
    step_index: int
    agent_id: str
    mission_id: str

    action: Action | None = None
    observation: Observation | None = None
    done: bool = False

    time_s: float | None = None
    error: str | None = None
    budgets_consumed: dict[str, float | int] = {}


class MetricScore(BaseModel):
    """Atomic metric score produced by a single metric."""

    model_config = ConfigDict(extra="forbid")

    metric_id: str
    direction: Literal["up", "down"] = "up"
    value: float
    details: JsonDict = {}


class ScoreReport(BaseModel):
    """Aggregated scores for a run."""

    model_config = ConfigDict(extra="forbid")

    run_id: str
    per_metric: list[MetricScore]
    aggregates: JsonDict


# ---------- Specifications for environment actions ----------


class RoundInfo(BaseModel):
    """Per-round context for the agent.

    Attributes:
        round_index: Zero-based round number.
        remaining_rounds: Rounds left including the current one.
        budgets_snapshot: Lightweight snapshot of budgets (e.g., time/samples/memory).

    """

    round_index: int
    remaining_rounds: int
    budgets_snapshot: Dict[str, Any] = Field(
        default_factory=dict,
        description="e.g., {'time_s_left': 12.3, 'samples_left': 500, 'memory_mb_left': None}",
    )


class ExperimentSpace(BaseModel):
    """Advertised experiment space for this round.

    Attributes:
        variables: Mapping of controllable variable -> allowed domain values (JSON-serializable).
        max_n: Optional cap on sample size per experiment (None means unlimited/unspecified).
    """

    variables: Dict[str, List[Any]] = Field(
        ..., description="Controllable variable -> list of allowed values"
    )
    max_n: Optional[int] = None


class AvailableActions(BaseModel):
    """Exactly two top-level options each round.

    Attributes:
        experiment: The full experiment space (variables and domains).
        answer: Intentionally empty; agent signals it's ready to submit.
    """

    experiment: ExperimentSpace
    answer: Dict[str, Any] = Field(default_factory=dict)


class Samples(BaseModel):
    """A single dataset produced by the environment.

    Attributes:
        kind: 'observational' or 'interventional'.
        data: Columnar mapping var -> list of values (all columns same length).
        n: Row count.
        interventions: The do()-mapping used if interventional; else None.
        seed: RNG seed actually used to generate the data.
        key: Deterministic key derived from the request (audit/repro).
    """

    kind: str
    data: Mapping[str, List[Any]]
    n: int
    interventions: Optional[Mapping[str, Any]] = None
    seed: int
    key: str


class SamplesBatch(BaseModel):
    """A collection of datasets (often size=1)."""

    items: List[Samples]


# TODO: There could be another name for this class. (although it is not that bad.)
class ActionOutcome(BaseModel):
    """Result of executing an action.

    Attributes:
        action_kind: 'experiment' | 'answer' | 'unknown'.
        action_payload: Normalized payload the environment applied.
        samples: Datasets produced (if any).
        feedback: Mission/environment feedback (e.g., validation result).
    """

    action_kind: str
    action_payload: Dict[str, Any] = Field(default_factory=dict)
    samples: Optional[SamplesBatch] = None
    feedback: Optional[Dict[str, Any]] = (
        None  # TODO: Feedback should be a model, since it will always be the same. (e.g., {"metrics":{"result": 1.0, "behavior": 0.5}, "valid": True, "message": "All good!"})
    )
