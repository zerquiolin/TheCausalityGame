from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Type, TypeVar

from TheCausalityGame.core.infra.serialization import dumps, loads, get_class_path

T = TypeVar("T", bound="Serializable")


class Serializable(ABC):
    """Abstract base for objects that can be represented as a spec & JSON.

    The canonical spec we use across the framework is:
        {"class": "<module>:<ClassName>", "config": {...}}
    """

    @abstractmethod
    def to_spec(self) -> Dict[str, Any]:
        """Return a canonical spec for this instance."""

    @classmethod
    @abstractmethod
    def from_spec(cls: Type[T], spec: Dict[str, Any]) -> T:
        """Create an instance from a canonical spec."""

    # ----- JSON helpers (backed by strict JSON) -----

    def to_json(self) -> str:
        """Strict JSON dump of the canonical spec (for persistence/sharing)."""
        return dumps(self.to_spec(), ensure_ascii=True, indent=None)

    @classmethod
    def from_json(cls: Type[T], s: str) -> T:
        """Strict JSON load (for persistence/sharing)."""
        spec = loads(s)
        if not isinstance(spec, dict):
            raise TypeError("JSON must represent an object/spec (dict).")
        return cls.from_spec(spec)


class ConfigDictSerializable(Serializable):
    """Convenience base class for components that are fully described by a config dict.

    Subclasses should:
      - accept **config in __init__ (no required positional args)
      - call super().__init__(**config) to store the config dict
      - use self._config when constructing behavior
    """

    _config: Dict[str, Any]

    def __init__(self, **config: Any) -> None:  # type: ignore[override]
        self._config = dict(config) if config else {}

    # You may override this if you need to reshape/validate config before persistence
    def _serialize_config(self) -> Dict[str, Any]:
        return dict(self._config)

    @classmethod
    def _deserialize_config(cls, cfg: Dict[str, Any]) -> Dict[str, Any]:
        # Hook point for subclasses that need to massage config before __init__
        return dict(cfg)

    def to_spec(self) -> Dict[str, Any]:
        return {
            "class": get_class_path(type(self)),
            "config": self._serialize_config(),
        }

    @classmethod
    def from_spec(cls: Type[T], spec: Dict[str, Any]) -> T:
        cls_path = spec.get("class")
        if not cls_path:
            raise ValueError("Spec is missing 'class' path")
        if cls_path != get_class_path(cls):
            # It’s fine to be strict here—callers should dispatch to the right class.
            raise ValueError(
                f"Spec class mismatch: spec has {cls_path}, loader is {get_class_path(cls)}"
            )
        cfg = spec.get("config") or {}
        if not isinstance(cfg, dict):
            raise TypeError("'config' must be a dict in spec.")
        cfg = cls._deserialize_config(cfg)
        return cls(**cfg)  # type: ignore[misc]
