"""Hook contracts and canonical event names."""

from __future__ import annotations

from typing import Any, Literal, Protocol

# TODO: This might be better as an enum. Given that it will be easier to use and extend.
EventName = Literal[
    "on_run_start",
    "on_run_finish",
    "on_round_start",
    "on_round_finish",
    "before_agent_act",
    "after_agent_act",
    "before_env_generate_samples",
    "after_env_generate_samples",
    "before_metric_eval",
    "after_metric_eval",
    "on_budget_violation",
    "on_component_error",
    "on_artifact_emitted",
]


class Hook(Protocol):
    """A hook implementation that subscribes to canonical events.

    Implementers may expose methods named after the events, e.g.:
    `def on_round_start(self, **payload) -> None: ...`
    The runtime event bus discovers and calls matching methods.
    """

    id: str

    def handles(self) -> list[EventName]:
        """Return the list of events this hook wants to receive."""
        ...

    def configure(self, config: dict[str, Any]) -> None:
        """Receive configuration values after construction."""
        ...
