from __future__ import annotations

from typing import Any

from .serializable import ConfigDictSerializable
from .dto import MetricScore, ProblemInstance, StepRecord


class BaseMetric(ConfigDictSerializable):
    """Metric contract + serializable base."""

    def evaluate(
        self,
        manifest: ProblemInstance,
        transcripts: list[StepRecord],
        truth_handle: Any,
    ) -> MetricScore:
        """Compute a score for this run.

        Returns:
            MetricScore including an id/direction/value and optional details.
        """
        raise NotImplementedError
