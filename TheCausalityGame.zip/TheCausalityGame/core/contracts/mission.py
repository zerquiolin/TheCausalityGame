from __future__ import annotations

from typing import Any

from .serializable import ConfigDictSerializable


class BaseMission(ConfigDictSerializable):
    """Mission contract + serializable base."""

    # Called by Environment
    def validate_submit(self, payload: dict[str, Any], *, trusted: bool) -> Any:
        """Validate/normalize a deliverable. Raise if invalid."""
        raise NotImplementedError

    # Called by metrics: the mission decides how to expose truth
    def truth_handle_for_metrics(self, scm: Any) -> Any:
        """Return a handle or value used by metrics to compute ground truth."""
        raise NotImplementedError

    # Optional: allow mission to provide a custom Environment factory
    def build_environment(self, scm: Any) -> Any:
        """Return an Environment instance or raise to use the default one."""
        raise NotImplementedError
