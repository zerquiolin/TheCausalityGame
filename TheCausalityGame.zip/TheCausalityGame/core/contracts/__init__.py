"""Public contract exports for TheCausalityGame core."""

from __future__ import annotations

from .agent import AgentContext, BaseAgent
from .dto import (
    Action,
    BudgetSpec,
    HookSpec,
    MetricScore,
    Observation,
    ProblemInstance,
    RunPlan,
    ScoreReport,
    StepRecord,
)
from .errors import (
    BudgetExceededError,
    ConfigurationError,
    DiscoveryError,
    InvalidAction,
    LoadError,
    SecurityViolation,
    TCGError,
    TimeoutExceeded,
)
from .hooks import EventName, Hook
from .metric import Metric, SCMTruth
from .mission import Mission
from .output import Output
from .scm import BaseSCM, NodeSCM, VariableSpec
from .serializable import JSONSerializable

__all__ = [
    "JSONSerializable",
    "ProblemInstance",
    "RunPlan",
    "BudgetSpec",
    "HookSpec",
    "Observation",
    "Action",
    "StepRecord",
    "MetricScore",
    "ScoreReport",
    "BaseAgent",
    "AgentContext",
    "Mission",
    "Metric",
    "SCMTruth",
    "BaseSCM",
    "NodeSCM",
    "VariableSpec",
    "Output",
    "Hook",
    "EventName",
    "TCGError",
    "ConfigurationError",
    "DiscoveryError",
    "LoadError",
    "InvalidAction",
    "BudgetExceededError",
    "TimeoutExceeded",
    "SecurityViolation",
]
