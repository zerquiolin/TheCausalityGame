from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from TheCausalityGame.core.contracts.dto import ProblemInstance
from TheCausalityGame.core.infra.settings import RuntimeSettings


@dataclass(frozen=True, slots=True)
class GameInstance:
    """Immutable container for a single benchmark run.

    Attributes:
        manifest: Validated ProblemInstance (DTO).
        settings: Runtime toggles (dev vs restricted, debug, trusted).
        run_id: Stable run identifier (defaults to manifest.id).
    """

    manifest: ProblemInstance
    settings: RuntimeSettings
    run_id: str

    @classmethod
    def build(
        cls, *, manifest: ProblemInstance, settings: RuntimeSettings
    ) -> "GameInstance":
        return cls(manifest=manifest, settings=settings, run_id=manifest.id)
