from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Mapping, Tuple

from TheCausalityGame.core.contracts.agent import BaseAgent
from TheCausalityGame.core.contracts.decisions import (
    Decision,
    Intervene,
    SubmitFinal,
    SubmitPartial,
)
from TheCausalityGame.core.contracts.dto import (
    Action,
    ActionOutcome,
    AvailableActions,
    ExperimentSpace,
    Observation,
    RoundInfo,
    Samples,
    SamplesBatch,
    StepRecord,
)
from TheCausalityGame.core.infra.determinism import (
    hash_intervention_key,
    make_intervention_seed,
)
from TheCausalityGame.core.infra.logging_ import get_logger

HookEmit = Callable[[str, dict[str, Any]], None]
WriteStep = Callable[[StepRecord], None]


@dataclass(slots=True)
class Environment:
    """Stateless environment (SCM + Mission) with a template run loop.

    The action surface is restricted to two verbs:
      - experiment: observational (no interventions) or interventional (mapping of var->value), plus n.
      - answer: signal readiness to submit (no fields).
    """

    scm: Any
    mission: Any

    # TODO: The environment should also have the history of the agent's decisions and outcomes, so that it can be used to compute metrics or other statistics.

    # -------------------- Thin API --------------------

    def generate_samples(
        self,
        *,
        n: int | None,
        interventions: Mapping[str, Any] | None,
        seed: int | None,
    ) -> Mapping[str, list[Any]]:
        """Delegate sampling to the SCM."""
        return self.scm.generate_samples(n=n, interventions=interventions, seed=seed)

    def mission_validate_submit(self, payload: dict[str, Any], *, trusted: bool) -> Any:
        """Delegate deliverable validation to the Mission."""
        return self.mission.validate_submit(payload, trusted=trusted)

    def truth_handle_for_metrics(self) -> Any:
        """Let the Mission compute/own ground-truth."""
        return self.mission.truth_handle_for_metrics(self.scm)

    # -------------------- Template run loop --------------------

    def run(
        self,
        *,
        agent_id: str,
        agent: BaseAgent,
        rounds: int,
        trusted: bool,
        hook_emit: HookEmit,
        write_step: WriteStep,
    ) -> dict[str, Any]:
        """Execute the full round loop and return a summary dict."""
        logger = get_logger("tcg.env")
        done = False
        last_deliverable: dict[str, Any] | None = None

        hook_emit("run_start", {"agent_id": agent_id})
        self._mount_components()  # allow mission to mount if needed # TODO: Move to

        for r in range(rounds):
            if done:
                break

            # TODO: All the steps could be breaken down into methods.

            hook_emit("round_start", {"agent_id": agent_id, "round": r})

            # Build round info + available actions
            round_info = self._round_info(round_index=r, total_rounds=rounds)
            available = self._available_actions()

            # TODO: This might not even be needed.
            # Step 1: initial observation
            observation = Observation(kind="status", payload={"round": r})
            write_step(
                StepRecord(
                    round_index=r,
                    step_index=0,
                    agent_id=agent_id,
                    mission_id=type(self.mission).__name__,
                    observation=observation,
                )
            )
            hook_emit(
                "before_act",
                {
                    "agent_id": agent_id,
                    "round": r,
                    "experiment_vars": list(available.experiment.variables.keys()),
                },
            )

            # Step 2: agent decision
            decision: Decision = agent.act(round_info, available)

            # Step 3: apply decision
            action, outcome, observation = (
                self._apply_decision(  # TODO: This should only receive the outcome.
                    decision,
                    agent=agent,
                    trusted=trusted,
                    round_index=r,
                    available=available,
                )
            )  # TODO: Fix method.

            # Inform agent about the outcome (samples/feedback)
            agent.inform(outcome)

            write_step(
                StepRecord(
                    round_index=r,
                    step_index=1,
                    agent_id=agent_id,
                    mission_id=type(self.mission).__name__,
                    action=action,
                    observation=observation,
                    done=action.kind in ("submit_final",),
                )
            )
            hook_emit(
                "after_act",
                {
                    "agent_id": agent_id,
                    "round": r,
                    "action": action.kind,
                    "rows": (observation.payload or {}).get("rows"),
                    "intervention_key": (observation.payload or {}).get(
                        "intervention_key"
                    ),
                },
            )

            # TODO: There is no "Partial" or "Final" decision, there is only "Answer" which is the current agent answer to the mission.(i.e., The (partial/final) answer to the mission at a certain round.)
            if action.kind == "submit_partial":
                last_deliverable = (outcome.feedback or {}).get("deliverable")  # type: ignore[assignment]
                hook_emit("submit_partial", {"agent_id": agent_id, "round": r})
            elif action.kind == "submit_final":
                last_deliverable = (outcome.feedback or {}).get("deliverable")  # type: ignore[assignment]
                done = True
                hook_emit("submit_final", {"agent_id": agent_id, "round": r})

            hook_emit("round_end", {"agent_id": agent_id, "round": r})

        hook_emit("run_end", {"agent_id": agent_id})
        logger.info(
            "run finished", extra={"agent_id": agent_id, "rounds": rounds, "done": done}
        )
        return {
            "done": done,  # TODO: This might not even be needed nor useful.
            "last_deliverable": last_deliverable,
        }  # TODO: This should return the history of the agent's decisions and outcomes, so that it can be used to compute metrics or other statistics.

    # -------------------- Micro-steps (override as needed) --------------------

    def _mount_components(self) -> None:
        """Give SCM to mission before the run starts."""
        if hasattr(self.mission, "mount"):
            self.mission.mount(self.scm)

    def _round_info(self, *, round_index: int, total_rounds: int) -> RoundInfo:
        """Create the per-round info snapshot."""
        remaining = total_rounds - round_index
        return RoundInfo(
            round_index=round_index,
            remaining_rounds=remaining,
            budgets_snapshot={
                "time_s_left": None,
                "samples_left": None,
                "memory_mb_left": None,
            },
        )

    def _available_actions(self) -> AvailableActions:
        """Compute the two canonical actions (experiment, answer) from the SCM."""
        controllable: dict[str, list] = {}
        # Expect SCM to expose .nodes (fallback to empty if absent)
        nodes = getattr(self.scm, "nodes", {}) or {}
        for node in getattr(nodes, "values", lambda: [])():
            if getattr(node, "accessibility", None) == "controllable":
                domain = getattr(node, "domain", None)
                if domain is not None:
                    controllable[getattr(node, "name", "unknown")] = list(domain)
        exp_space = ExperimentSpace(variables=controllable, max_n=None)
        return AvailableActions(experiment=exp_space, answer={})

    def _validate_interventions(
        self, interventions: Mapping[str, Any], exp: ExperimentSpace
    ) -> None:
        """Validate interventions against the advertised experiment space."""
        for var, val in interventions.items():
            if var not in exp.variables:
                raise ValueError(f"Unknown intervention variable: {var}")
            if val not in exp.variables[var]:
                raise ValueError(
                    f"Value {val!r} not in domain of {var}: {exp.variables[var]!r}"
                )

    def _apply_decision(
        self,
        decision: Decision,
        *,
        agent: BaseAgent,
        trusted: bool,
        round_index: int,
        available: AvailableActions,
    ) -> Tuple[Action, ActionOutcome, Observation]:
        """Apply a Decision and return (Action, ActionOutcome, Observation)."""

        # EXPERIMENT: observational (empty interoentions) or interventional (non-empty)
        # TODO: There is only two kinds of decisions: Experiment and Asnwer.
        if isinstance(decision, Intervene):  # TODO: Change to "Experiment"
            # TODO: There is more than one experiment, so it is required to iterate over them.
            self._validate_interventions(
                decision.interventions or {}, available.experiment
            )  # TODO: The validation should be done inside the loop for each experiment. (If interventions are present.)

            # TODO: I think this could be simplified. The seed / rng is derived from the intervention object.
            ctx = agent.context
            ikey = hash_intervention_key(
                base_seed=ctx.base_seed,
                manifest_id=ctx.manifest_id,
                agent_id=ctx.agent_id,
                round_index=round_index,
                interventions=decision.interventions,
                n=decision.n,
            )
            derived_seed = make_intervention_seed(
                base_seed=ctx.base_seed,
                manifest_id=ctx.manifest_id,
                agent_id=ctx.agent_id,
                round_index=round_index,
                interventions=decision.interventions,
                n=decision.n,
            )
            seed_to_use = decision.seed if decision.seed is not None else derived_seed

            # TODO: I think we need to migrate to rng in order to support reproducibility on sequential runs. (And avoid the same samples each time.)
            ds = self.generate_samples(
                n=decision.n, interventions=decision.interventions, seed=seed_to_use
            )

            # TODO: This might not be useful atm. But it would be useful to have a step record here.
            action = Action(
                kind="experiment",
                payload={
                    "interventions": dict(decision.interventions),
                    "n": decision.n,
                    "seed": seed_to_use,
                    "key": ikey,
                },
            )  # TODO: Actually, this is not needed, since the experiments are a set not a single one.

            rows = 0
            cols = []
            if isinstance(ds, Mapping):
                cols = list(ds.keys())
                try:
                    rows = len(next(iter(ds.values()))) if ds else 0
                except Exception:
                    rows = 0

            # TODO: This must be within the loop for each experiment. Additionally, it might be useful to save it at class level along with the prior experiments.
            samples = Samples(
                kind="interventional" if decision.interventions else "observational",
                data=ds,  # type: ignore[arg-type]
                n=rows,
                interventions=decision.interventions or {},
                seed=seed_to_use,
                key=ikey,
            )

            # TODO: Evaluate the current answer of the agent, and return it as feedback.

            # TODO: This should be a batch of samples, not a single one.
            outcome = ActionOutcome(
                action_kind="experiment",
                action_payload=action.payload,
                samples=SamplesBatch(items=[samples]),
                # TODO: This could return the evaluation of the current answer (partial) of the agent. That way, given the information about the new data, and the information of its current answer, the agent could improve its potential final answer.
                feedback=None,  # TODO: Somehow the feedback should include the result of the metric evaluation.
            )
            # TODO: This might work for Step Record, might need polishing.
            observation = Observation(
                kind="dataset",
                payload={"rows": rows, "cols": cols, "intervention_key": ikey},
            )
            return (
                action,
                outcome,
                observation,
            )  # TODO: The only reasonable returnable object is the Outcome.

        # TODO: There is no "Partial" or "Final" decision, there is only "Answer" which is the current agent answer to the mission.(i.e., The (partial/final) answer to the mission at a certain round.)
        # ANSWER (partial/final) – validate via mission
        if isinstance(decision, SubmitPartial):
            # TODO: This is actually clever.
            validated = self.mission_validate_submit(
                decision.deliverable.data, trusted=trusted
            )
            action = Action(kind="submit_partial", payload={})
            outcome = ActionOutcome(
                action_kind="answer",
                action_payload={},
                samples=None,
                feedback={"deliverable": validated, "partial": True},
            )
            observation = Observation(
                kind="feedback", payload={"deliverable": validated, "partial": True}
            )
            return action, outcome, observation

        if isinstance(decision, SubmitFinal):
            validated = self.mission_validate_submit(
                decision.deliverable.data, trusted=trusted
            )
            action = Action(kind="submit_final", payload={})
            outcome = ActionOutcome(
                action_kind="answer",
                action_payload={},
                samples=None,
                feedback={"deliverable": validated, "final": True},
            )
            observation = Observation(
                kind="feedback", payload={"deliverable": validated, "final": True}
            )
            return action, outcome, observation

        # TODO: This could work, it is required to use another model to represent actions and observations. (i.e., Step.).
        # Unknown → status
        action = Action(kind="unknown", payload={})
        outcome = ActionOutcome(
            action_kind="unknown", action_payload={}, samples=None, feedback=None
        )
        observation = Observation(
            kind="status", payload={"warning": "unknown-decision"}
        )
        return action, outcome, observation
