from __future__ import annotations

from pathlib import Path
from typing import Any

from TheCausalityGame.core.engine.game_instance import GameInstance
from TheCausalityGame.core.runtime.orchestrator import run_all_agents


class Game:
    """Facade over the orchestrator to run a GameInstance.

    Keeps a thin layer for future policies (e.g., resume, retry, checkpointing).
    """

    def __init__(self, *, instance: GameInstance, runs_dir: str | Path) -> None:
        self._instance = instance
        self._runs_dir = Path(runs_dir)

    def run(self) -> dict[str, dict[str, Any]]:
        """Run all agents according to the manifest's run plan.

        Returns:
            Per-agent summary dict with `done`, `last_deliverable`, `elapsed_s`.
        """
        return run_all_agents(
            manifest=self._instance.manifest,
            runs_dir=self._runs_dir / self._instance.run_id,
            settings=self._instance.settings,
        )
