"""CLI package for TheCausalityGame."""
