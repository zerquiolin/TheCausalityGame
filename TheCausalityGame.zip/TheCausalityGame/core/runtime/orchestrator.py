from __future__ import annotations

import os
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable

from TheCausalityGame.core.contracts.agent import AgentContext
from TheCausalityGame.core.contracts.dto import (
    AgentSpec,
    MetricScore,
    ProblemInstance,
    ScoreReport,
    StepRecord,
)
from TheCausalityGame.core.engine.environment import Environment
from TheCausalityGame.core.infra.artifacts import (
    append_jsonl,
    ensure_run_dir,
    snapshot_provenance,
    write_json,
)
from TheCausalityGame.core.infra.logging_ import get_logger
from TheCausalityGame.core.infra.registry import build_from_spec, load_class
from TheCausalityGame.core.infra.settings import RuntimeSettings

# TODO: This might be better a class.


def _emit_noop(event: str, payload: dict[str, Any]) -> None:  # pragma: no cover
    pass


def _make_hook_emitter(
    hooks: list[Any] | None,
) -> Callable[[str, dict[str, Any]], None]:
    if not hooks:
        return _emit_noop
    instances: list[Any] = []
    for h in hooks:
        class_path = getattr(h, "class_path", None) or (
            h.get("class_path") if isinstance(h, dict) else None
        )
        entry_point = getattr(h, "entry_point", None) or (
            h.get("entry_point") if isinstance(h, dict) else None
        )
        cfg = (
            getattr(h, "config", None)
            or (h.get("config") if isinstance(h, dict) else {})
            or {}
        )
        target = class_path or entry_point
        if not target:
            continue
        try:
            cls = load_class(target)
            inst = cls(**cfg)
            if callable(inst):
                instances.append(inst)
        except Exception:
            continue

    def emit(event: str, payload: dict[str, Any]) -> None:
        for inst in instances:
            try:
                inst(event, payload)
            except Exception:
                continue

    return emit


def _build_environment(manifest: ProblemInstance) -> Environment:
    scm = build_from_spec(manifest.scm_spec)
    mission_cls = load_class(manifest.mission_spec["class"])
    mission = mission_cls(**(manifest.mission_spec.get("config") or {}))

    # TODO: The environment should also (maybe) have another class (evaluator) that will handle the mount, evaluation and store of the results of each metric (i.e., Custom or Core.).

    if hasattr(mission, "build_environment") and callable(
        getattr(mission, "build_environment")
    ):
        return mission.build_environment(  # TODO: Actually, this should the mount method of the mission, which at the same time will mount the metrics.
            scm
        )  # TODO: I don't think this is the right way to do it, since the environment should be built with the manifest and the agent's context.
    return Environment(scm=scm, mission=mission)


# TODO: This should be evaluated within the environment, not here.
def _evaluate_metrics(
    *,
    manifest: ProblemInstance,
    agent_id: str,
    run_dir: Path,
    transcripts: list[StepRecord],
    env: Environment,
) -> ScoreReport:
    scores: list[MetricScore] = []
    metric_specs = [
        manifest.metric_specs.behavior,
        manifest.metric_specs.result,
    ] + list(manifest.custom_metric_specs or [])
    for ms in metric_specs:
        metric_cls = load_class(ms.class_)
        metric = metric_cls(**(ms.config or {}))
        score: MetricScore = metric.evaluate(
            manifest,
            transcripts,
            env.truth_handle_for_metrics(),
        )
        scores.append(score)

    report = ScoreReport(run_id=manifest.id, per_metric=scores, aggregates={})
    write_json(run_dir / "scores.json", report.model_dump())
    append_jsonl(run_dir / "metrics_raw.jsonl", (s.model_dump() for s in scores))
    return report


# TODO: Check, but I think it is okay.
def _write_step(run_dir: Path) -> Callable[[StepRecord], None]:
    path = run_dir / "transcripts.jsonl"

    def writer(step: StepRecord) -> None:
        append_jsonl(path, [step.model_dump()])

    return writer


def _run_one_agent(
    *,
    manifest: ProblemInstance,
    settings: RuntimeSettings,
    runs_dir: str | Path,
    agent_spec: AgentSpec,
    hook_emit: Callable[[str, dict[str, Any]], None],
) -> tuple[str, dict[str, Any]]:
    # TODO: We should check for both class instance and class spec.
    # TODO: This initializations are great, but they should be cleaned up.
    logger = get_logger("tcg.orchestrator")
    agent_id = agent_spec.id
    run_dir = ensure_run_dir(runs_dir, manifest.id, agent_id)

    write_json(run_dir / "run_manifest.json", manifest.model_dump())
    snapshot_provenance(run_dir)

    env = _build_environment(manifest)  # TODO: Check this.

    agent = build_from_spec(
        {"class": agent_spec.class_, "config": agent_spec.config or {}}
    )  # TODO: I think this should already come as an spec.

    # Create and inject context into the agent instance
    ctx = AgentContext(
        config=agent_spec.config or {},
        manifest_id=manifest.id,
        agent_id=agent_id,
        base_seed=(manifest.seeds.get("base") if manifest.seeds else None),
    )
    agent.set_context(ctx)

    transcripts: list[StepRecord] = []  # TODO: Clever.
    writer = _write_step(run_dir)

    def capture_step(step: StepRecord) -> None:
        transcripts.append(step)
        writer(step)

    result = env.run(
        agent_id=agent_id,
        agent=agent,
        rounds=manifest.run_plan.rounds,
        trusted=settings.trusted,
        hook_emit=hook_emit,
        write_step=capture_step,
    )

    # TODO: This might work for custom metrics.
    # TODO: This actually should be done with another class within the environment, which will handle all the metric processing.
    report = _evaluate_metrics(
        manifest=manifest,
        agent_id=agent_id,
        run_dir=Path(run_dir),
        transcripts=transcripts,
        env=env,
    )
    summary = {
        "done": bool(
            result.get("done", True)
        ),  # TODO: Not relevant. (maybe as an indicator of whether the agent finished its run or not.)
        "elapsed_s": (
            float(result.get("elapsed_s", 0.0))
            if isinstance(result.get("elapsed_s", 0.0), (int, float))
            else 0.0
        ),
        "last_deliverable": result.get("last_deliverable"),
        "report": report.model_dump(),
    }
    write_json(Path(run_dir) / "summary.json", summary)
    logger.info("Agent finished", extra={"agent_id": agent_id})
    return agent_id, summary


def run_all_agents(
    *,
    manifest: ProblemInstance,
    runs_dir: str | Path,
    settings: RuntimeSettings,
) -> dict[str, dict[str, Any]]:
    hook_emit = _make_hook_emitter(manifest.hook_plan)
    agents = list(manifest.agent_specs)
    results: dict[str, dict[str, Any]] = {}

    if manifest.run_plan.execution == "sequential":
        for spec in agents:
            agent_id, res = _run_one_agent(
                manifest=manifest,
                settings=settings,
                runs_dir=runs_dir,
                agent_spec=spec,
                hook_emit=hook_emit,
            )
            results[agent_id] = res
        return results

    backend = manifest.run_plan.parallel_backend
    if backend not in ("thread", "process"):
        backend = "thread"
    Executor = ThreadPoolExecutor if backend == "thread" else ProcessPoolExecutor
    default_workers = (
        len(agents) if backend == "thread" else (os.cpu_count() or 1)
    )  # TODO: This should have a cap to avoid overloading the system.
    max_workers = (
        manifest.run_plan.max_workers or default_workers
    )  # TODO: This should also have a sanity check that the entirety of the cores are not used.

    with Executor(max_workers=max_workers) as ex:
        futs = [
            ex.submit(
                _run_one_agent,
                manifest=manifest,
                settings=settings,
                runs_dir=runs_dir,
                agent_spec=spec,
                hook_emit=hook_emit,
            )
            for spec in agents
        ]
        for fut in as_completed(futs):
            agent_id, res = fut.result()
            results[agent_id] = res
    return results
